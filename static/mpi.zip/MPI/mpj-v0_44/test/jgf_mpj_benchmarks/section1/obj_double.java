package jgf_mpj_benchmarks.section1;

import java.io.*;
//import jgfutil.*; 
import jgf_mpj_benchmarks.*; 

class obj_double implements Serializable {

  double x;

  public obj_double(double x) {
   this.x = x;
  }

}

